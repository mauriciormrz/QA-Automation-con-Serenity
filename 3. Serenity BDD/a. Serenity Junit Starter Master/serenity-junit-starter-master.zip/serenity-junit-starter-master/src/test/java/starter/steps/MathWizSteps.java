package starter.steps;

import net.thucydides.core.annotations.Step;

public class MathWizSteps {

    String actor;

    @Step("#actor tiene {0}")
    public void tiene(int amount) {
        // TODO
    }

    @Step("#actor agrega {0}")
    public void suma(int amount) {
        // TODO
    }

    @Step("#actor deberia tener {0}")
    public void deberiaTener(int expectedTotal) {
        // TODO
    }
}
